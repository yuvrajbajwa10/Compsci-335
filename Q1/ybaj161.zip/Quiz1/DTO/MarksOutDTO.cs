﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Quiz1.DTO
{
    public class MarksOutDTO
    {
        public int Id { get; set; }
        public float A1 { get; set; }
        public float A2 { get; set; }
    }
}
